<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../utils/AuthMiddleware.php';

class UserController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new User();
    }
    
    public function getProfile() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            ApiResponse::send(405, ['error' => 'Método não permitido']);
        }
        
        $userId = AuthMiddleware::authenticate();
        $userData = $this->userModel->getProfile($userId);
        
        if (!$userData) {
            ApiResponse::send(404, ['error' => 'Usuário não encontrado']);
        }
        
        ApiResponse::send(200, $userData);
    }
    
    public function getLearningAreas() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            ApiResponse::send(405, ['error' => 'Método não permitido']);
        }
        
        $userId = AuthMiddleware::authenticate();
        $learningAreas = $this->userModel->getLearningAreas($userId);
        
        ApiResponse::send(200, $learningAreas);
    }
}