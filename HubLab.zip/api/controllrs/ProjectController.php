<?php
require_once __DIR__ . '/../models/Project.php';
require_once __DIR__ . '/../utils/AuthMiddleware.php';

class ProjectController {
    private $projectModel;
    
    public function __construct() {
        $this->projectModel = new Project();
    }
    
    public function getActiveProjects() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            ApiResponse::send(405, ['error' => 'Método não permitido']);
        }
        
        $userId = AuthMiddleware::authenticate();
        $projects = $this->projectModel->getProjectsByStatus($userId, 'active');
        
        ApiResponse::send(200, $projects);
    }
    
    public function getCompletedProjects() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            ApiResponse::send(405, ['error' => 'Método não permitido']);
        }
        
        $userId = AuthMiddleware::authenticate();
        $projects = $this->projectModel->getProjectsByStatus($userId, 'completed');
        
        ApiResponse::send(200, $projects);
    }
}