<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/utils/ApiResponse.php';
require_once __DIR__ . '/utils/AuthMiddleware.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$endpoint = str_replace('/api/', '', $request_uri);

try {
    // Rotas da API
    switch ($endpoint) {
        case 'user/profile':
            require_once __DIR__ . '/controllers/UserController.php';
            $controller = new UserController();
            $controller->getProfile();
            break;
            
        case 'user/learning-areas':
            require_once __DIR__ . '/controllers/UserController.php';
            $controller = new UserController();
            $controller->getLearningAreas();
            break;
            
        case 'projects/active':
            require_once __DIR__ . '/controllers/ProjectController.php';
            $controller = new ProjectController();
            $controller->getActiveProjects();
            break;
            
        case 'projects/completed':
            require_once __DIR__ . '/controllers/ProjectController.php';
            $controller = new ProjectController();
            $controller->getCompletedProjects();
            break;
            
        default:
            ApiResponse::send(404, ['error' => 'Endpoint não encontrado']);
            break;
    }
} catch (PDOException $e) {
    ApiResponse::send(500, ['error' => 'Erro no banco de dados']);
} catch (Exception $e) {
    ApiResponse::send(500, ['error' => $e->getMessage()]);
}