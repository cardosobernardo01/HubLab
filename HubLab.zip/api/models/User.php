<?php
require_once __DIR__ . '/../config/database.php';

class User {
    private $db;
    
    public function __construct() {
        $this->db = DatabaseConfig::getConnection();
    }
    
    public function getProfile($userId) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute(['id' => $userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) return false;

        // Busca estatísticas
        $statsStmt = $this->db->prepare("
            SELECT 
                COUNT(*) as projectsCount,
                SUM(investment) as investedAmount,
                SUM(return) as returnAmount,
                ROUND((SUM(return) - SUM(investment)) / SUM(investment) * 100, 2) as successRate
            FROM projects 
            WHERE user_id = :userId
        ");
        $statsStmt->execute(['userId' => $userId]);
        $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

        return [
            'name' => $user['name'],
            'title' => $user['title'],
            'avatar' => $user['avatar_url'],
            'stats' => [
                'successRate' => ($stats['successRate'] ?? 0) . '%',
                'projectsCount' => $stats['projectsCount'] ?? 0,
                'investedAmount' => 'R$ ' . number_format($stats['investedAmount'] ?? 0, 2, ',', '.'),
                'returnAmount' => 'R$ ' . number_format($stats['returnAmount'] ?? 0, 2, ',', '.')
            ]
        ];
    }
    
    public function getLearningAreas($userId) {
        $stmt = $this->db->prepare("
            SELECT DISTINCT area 
            FROM user_learning_areas 
            WHERE user_id = :userId
            ORDER BY proficiency DESC
            LIMIT 5
        ");
        $stmt->execute(['userId' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}