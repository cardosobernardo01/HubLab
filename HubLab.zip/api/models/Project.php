<?php
require_once __DIR__ . '/../config/database.php';

class Project {
    private $db;
    
    public function __construct() {
        $this->db = DatabaseConfig::getConnection();
    }
    
    public function getProjectsByStatus($userId, $status) {
        $query = "
            SELECT 
                id, 
                title, 
                description, 
                start_date as startDate, 
                end_date as endDate,
                investment,
                " . ($status === 'active' ? 'expected_return' : 'actual_return') . " as return,
                ROUND((" . ($status === 'active' ? 'expected_return' : 'actual_return') . " - investment) / investment * 100, 2) as margin,
                :status as status
            FROM projects 
            WHERE user_id = :userId AND status = :status
            ORDER BY " . ($status === 'active' ? 'start_date' : 'end_date') . " DESC
            " . ($status === 'completed' ? 'LIMIT 10' : '');
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([
            'userId' => $userId,
            'status' => $status
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}