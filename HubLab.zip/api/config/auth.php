<?php
require_once __DIR__ . '/database.php';

class Auth {
    public static function verifyToken($token) {
        // Implementação real deve usar JWT ou similar
        $pdo = DatabaseConfig::getConnection();
        $stmt = $pdo->prepare("SELECT user_id FROM user_tokens WHERE token = :token AND expires_at > NOW()");
        $stmt->execute(['token' => $token]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result ? $result['user_id'] : false;
    }
}