<?php
class DatabaseConfig {
    const HOST = 'localhost';
    const NAME = 'biblioteca_digital';
    const USER = 'usuario';
    const PASS = 'senha_segura';
    
    public static function getConnection() {
        $pdo = new PDO(
            "mysql:host=" . self::HOST . ";dbname=" . self::NAME, 
            self::USER, 
            self::PASS
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
}