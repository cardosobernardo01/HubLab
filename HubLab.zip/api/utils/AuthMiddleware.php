<?php
require_once __DIR__ . '/../config/auth.php';

class AuthMiddleware {
    public static function authenticate() {
        $headers = getallheaders();
        
        if (!isset($headers['Authorization'])) {
            ApiResponse::send(401, ['error' => 'Token de autenticação não fornecido']);
        }

        $authHeader = $headers['Authorization'];
        $token = str_replace('Bearer ', '', $authHeader);
        $userId = Auth::verifyToken($token);
        
        if (!$userId) {
            ApiResponse::send(403, ['error' => 'Token inválido ou expirado']);
        }

        return $userId;
    }
}