    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Sistema de Partículas Alucinógeno
            const particleUniverse = document.getElementById('particleUniverse');
            const particleCount = 150;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 3 + 0.5;
                const posX = Math.random() * 100;
                const posY = Math.random() * 100 + 100;
                const duration = Math.random() * 30 + 30;
                const delay = Math.random() * 20;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${posX}%`;
                particle.style.top = `${posY}%`;
                particle.style.opacity = Math.random() * 0.3 + 0.1;
                particle.style.setProperty('--random-x', Math.random());
                particle.style.animation = `float-particle ${duration}s linear ${delay}s infinite`;
                
                particleUniverse.appendChild(particle);
            }
            
            // Criaturas do Sonho
            const dreamCreatures = document.getElementById('dreamCreatures');
            const creatures = [
                { 
                    type: 'butterfly',
                    svg: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path fill="rgba(255,126,157,0.7)" d="M50,15 C60,5 80,10 85,25 C95,45 85,65 65,75 C45,85 25,80 15,65 C5,45 15,25 30,15 C40,5 50,5 50,15 Z M30,40 C35,35 45,35 50,40 C55,35 65,35 70,40 C65,45 55,45 50,40 C45,45 35,45 30,40 Z"/></svg>',
                    startX: -20,
                    startY: 30,
                    endX: 120,
                    endY: 50,
                    size: 12,
                    delay: 0
                },
                {
                    type: 'cat',
                    svg: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path fill="rgba(245,245,247,0.8)" d="M50,20 C60,10 80,15 85,30 C95,40 90,60 80,70 C70,80 50,85 30,75 C20,65 15,45 25,30 C30,20 40,10 50,20 Z M40,40 C35,35 30,40 35,45 C30,50 35,55 40,50 C45,55 50,50 45,45 C50,40 45,35 40,40 Z M60,40 C55,35 50,40 55,45 C50,50 55,55 60,50 C65,55 70,50 65,45 C70,40 65,35 60,40 Z"/></svg>',
                    startX: 120,
                    startY: 70,
                    endX: -20,
                    endY: 60,
                    size: 15,
                    delay: 10
                }
            ];
            
            creatures.forEach(creature => {
                const element = document.createElement('div');
                element.classList.add('dream-creature');
                element.style.backgroundImage = `url("${creature.svg}")`;
                element.style.width = `${creature.size}%`;
                element.style.height = `${creature.size}%`;
                element.style.setProperty('--start-x', creature.startX);
                element.style.setProperty('--start-y', creature.startY);
                element.style.setProperty('--end-x', creature.endX);
                element.style.setProperty('--end-y', creature.endY);
                element.style.animationDuration = `${Math.random() * 40 + 60}s`;
                element.style.animationDelay = `${creature.delay}s`;
                
                dreamCreatures.appendChild(element);
            });
            
            // Feixes de Luz Cósmicos
            const lightBeams = document.getElementById('lightBeams');
            const beamCount = 5;
            
            for (let i = 0; i < beamCount; i++) {
                const beam = document.createElement('div');
                beam.classList.add('light-beam');
                beam.style.left = `${Math.random() * 100}%`;
                beam.style.animationDuration = `${Math.random() * 100 + 100}s`;
                beam.style.animationDelay = `${Math.random() * 20}s`;
                lightBeams.appendChild(beam);
            }
            
            // Interação com o Portal
            const entryPortal = document.getElementById('entryPortal');
            
            entryPortal.addEventListener('click', function() {
                this.style.transform = 'scale(0.9)';
                this.style.opacity = '0.7';
                
                // Efeito de transição dimensional
                document.querySelector('.book-cover').style.opacity = '0';
                document.querySelector('.book-cover').style.transform = 'translateY(20px) scale(0.95)';
                document.querySelector('.author-panel').style.transform = 'translateX(-200px)';
                
                // Efeito de explosão de partículas
                const particles = document.querySelectorAll('.particle');
                particles.forEach(p => {
                    p.style.animation = 'none';
                    p.style.transform = `translate(${Math.random() * 200 - 100}px, ${Math.random() * 200 - 100}px) scale(${Math.random() * 2})`;
                    p.style.opacity = '0';
                    p.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)';
                });
                
                setTimeout(() => {
                    window.location.href = 'indice.html';
                }, 1000);
            });
            
            // Botão de Outros Universos
            const moreBooksBtn = document.getElementById('moreBooksBtn');
            
            moreBooksBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // Efeito de portal se abrindo
                this.innerHTML = 'Abrindo Multiverso...';
                this.style.background = 'rgba(255, 126, 157, 0.15)';
                this.style.borderColor = 'rgba(46, 229, 157, 0.5)';
                
                // Criar mini-portal
                const miniPortal = document.createElement('div');
                miniPortal.style.position = 'absolute';
                miniPortal.style.width = '0';
                miniPortal.style.height = '0';
                miniPortal.style.borderRadius = '50%';
                miniPortal.style.background = 'radial-gradient(circle, rgba(46,229,157,0.3) 0%, transparent 70%)';
                miniPortal.style.boxShadow = '0 0 20px rgba(255,126,157,0.6)';
                miniPortal.style.top = '50%';
                miniPortal.style.left = '50%';
                miniPortal.style.transform = 'translate(-50%, -50%)';
                miniPortal.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)';
                this.appendChild(miniPortal);
                
                setTimeout(() => {
                    miniPortal.style.width = '200%';
                    miniPortal.style.height = '200%';
                    miniPortal.style.opacity = '0';
                }, 50);
                
                setTimeout(() => {
                    alert("Realidade alternativa: Biblioteca de Universos Paralelos");
                    this.innerHTML = 'Outros Universos <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59c.39-.39.39-1.02 0-1.41l-6.58-6.6c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z"/></svg>';
                    this.style.background = 'rgba(255, 255, 255, 0.03)';
                    this.style.borderColor = 'rgba(255, 126, 157, 0.3)';
                    miniPortal.remove();
                }, 2000);
            });
        });
  ll